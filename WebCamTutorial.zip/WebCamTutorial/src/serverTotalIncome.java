
public class serverTotalIncome { 
	serverTotalIncome() 
	{
		
	}

}
