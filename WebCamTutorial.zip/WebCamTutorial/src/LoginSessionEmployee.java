
public class LoginSessionEmployee {
	static  String loggedinName;
	
	public LoginSessionEmployee() {
		
	}
	
	public void setName(String name) {
		loggedinName=name;
	}
	
	public String getName() {
		return loggedinName;
	}

	/*public void setName(String name) {
		// TODO Auto-generated method stub
		loggedinName=name;
	}*/
}
